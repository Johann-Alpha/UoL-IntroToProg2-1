var noiseStep;
var prog;

function setup()
{
	createCanvas(512,512);
	stroke(255);
  	noFill();
	
	noiseStep = 0.01;
	
	prog = 0;
	
}

function draw()
{
	background(0);
	
	translate(width/2, height/2);
	beginShape();
	
	for(var i = 0; i < 100; i++)
	{
		
		var x = map(noise(i* noiseStep + prog),0,1,-500,500);
		var y = map(noise(i* noiseStep + prog + 1000),0,1,-500,500);
		
		
		vertex(x,y);
	}
	//console.log(noise(mouseX));
	endShape();
	
	prog += 0.05;
}



