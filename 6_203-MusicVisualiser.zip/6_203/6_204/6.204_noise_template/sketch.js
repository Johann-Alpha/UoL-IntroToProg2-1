

function setup()
{
	createCanvas(512,512);
	stroke(255);
  	noFill();
	
}

function draw()
{
	background(0);
	

}



