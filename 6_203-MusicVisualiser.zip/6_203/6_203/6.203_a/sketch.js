



var sample;
var isReady;
var fft;

function preload()
{
    soundFormats('mp3','wav');
    
    isReady = false;
    
    //load your sounds here
    sample = loadSound('assets/segweyAdiosClip.mp3', soundInit);
    sample.setVolume(0.5);
    
    
}

function soundInit()
{
    isReady = true;
}


function setup()
{
	createCanvas(1024, 576);
    textAlign(CENTER);
    textSize(32);
    
    amplitude = new p5.Amplitude();
    fft = new p5.FFT();

}

function draw()
{
    background(0);
    fill(255);
    noStroke();
    
    if(isReady && !sample.isPlaying())
    {
        text("Press any key to play sound", width/2, height/2);   
    }
    else if(sample.isPlaying())
    {
        
        var spectrum = fft.analyze();
		
        noStroke();
        fill(0,255,0,100); // spectrum is green
        for (var i = 0; i< spectrum.length; i++)
        {
            var x = map(i, 0, spectrum.length, 0, width);
            var h = -height + map(spectrum[i], 0, 255, height, 0);
            rect(x, height, width / spectrum.length, h )
        }
        
    }
}


function keyPressed()
{
    
    if(isReady && !sample.isPlaying())
    {
        sample.loop();
    }
    else if(sample.isPlaying())
    {
        sample.pause();
    }

}
