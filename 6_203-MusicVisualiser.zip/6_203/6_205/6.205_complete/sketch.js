
var sample;
var isReady;
var fft;
var rot;
var noiseStep;
var prog;
var gui;
var rotateThresh;
var progThresh;
var seedThresh;

function preload()
{
    soundFormats('mp3','wav');
    
    isReady = false;
    
    //load your sounds here
    sample = loadSound('assets/segweyAdiosClip.mp3', soundInit);
    sample.setVolume(0.5);
	noiseStep = 0.01;
	prog = 0;
	rotateThresh = 67;
	progThresh = 180;
	seedThresh = 100;
    
}

function soundInit()
{
    isReady = true;
}


function setup()
{
	createCanvas(1024, 576);
    textAlign(CENTER);
    textSize(32);
    
    amplitude = new p5.Amplitude();
    fft = new p5.FFT();
	rot = 0;
	
	gui = createGui('Audio Visualizer');
	
	sliderRange(0.001,1,0.001);
	gui.addGlobals('noiseStep');
	
	sliderRange(0,255,1);
	gui.addGlobals('rotateThresh');
	gui.addGlobals('progThresh');
	gui.addGlobals('seedThresh');

}

function draw()
{
    background(0);
    fill(255);
    noStroke();
    
    if(isReady && !sample.isPlaying())
    {
        text("Press any key to play sound", width/2, height/2);   
    }
    else if(sample.isPlaying())
    {
        
//        var spectrum = fft.analyze();
//		
//        noStroke();
//        fill(0,255,0,100); // spectrum is green
//        for (var i = 0; i< spectrum.length; i++)
//        {
//            var x = map(i, 0, spectrum.length, 0, width);
//            var h = -height + map(spectrum[i], 0, 255, height, 0);
//            rect(x, height, width / spectrum.length, h )
//        }
		
		
		fft.analyze();
		
		var b = fft.getEnergy("bass");
		var t = fft.getEnergy("treble");
		
		//ellipse(width/2 - 255, height/2, b);
		//ellipse(width/2 + 255, height/2, t);
		
        rotatingBlocks(t);
		noiseLine(b,t);
    }
	
	
	
	
}


function rotatingBlocks(energy)
{
	
	if(energy < rotateThresh)
	{
		rot += 0.01;
	}
	
	var r = map(energy, 0, 255, 20, 100);
	
	push();
	rectMode(CENTER);
	translate(width/2, height/2);
	rotate(rot);
	fill(255,0,0);
	
	
	var incr = width/(10 - 1);
	
	for(var i = 0; i < 10; i++)
	{
		rect(i * incr - width/2,0,r,r);
	}
	
	
	
	pop();
}

function noiseLine(energy, energy2)
{
	push();
	translate(width/2, height/2);
	beginShape();
	noFill();
	stroke(0,255,0);
	strokeWeight(3);
	
	for(var i = 0; i < 100; i++)
	{
		
		var x = map(noise(i* noiseStep + prog),0,1,-250,250);
		var y = map(noise(i* noiseStep + prog + 1000),0,1,-250,250);
		
		
		vertex(x,y);
	}
	//console.log(noise(mouseX));
	endShape();
	
	
	if(energy > progThresh)
	{
		prog += 0.05;
	}
	
	if(energy2 > seedThresh)
	{
		noiseSeed();
	}
	
	pop();
}


function keyPressed()
{
    
    if(isReady && !sample.isPlaying())
    {
        sample.loop();
    }
    else if(sample.isPlaying())
    {
        sample.pause();
    }

}
